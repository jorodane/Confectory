from pathlib import Path
import os,subprocess,signal,time,json,re,hashlib
r=Path('/workspace/Confectory');s=Path(__file__).parent;out=s/'untraced';out.mkdir(exist_ok=False);env=os.environ.copy()
for name in ['CONFECTORY_ENV4_TRACE','CONFECTORY_ENV4_STARTUP_GAP_MS']:env.pop(name,None)
methods=['CoreTests.test_artifact_parallel_publication_and_corrupt_entry_repair','WebUITests.test_actual_editor_v480_local_run_frame_ack_pause_step_reconnect_and_stop','WebUITests.test_run_history_command_admission_preserves_published_revision_and_rejects_stale_step','ProjectExecutionTests.test_actual_native_button_game_pause_single_draw_step_and_stop','ProjectExecutionTests.test_actual_native_engine_cooperative_frame_callbacks','ProjectExecutionTests.test_actual_owned_cooperative_frames_pause_step_reconnect_and_stop']
assert not Path('/tmp/.X11-unix/X97').exists()
stream=(out/'xorg-console.log').open('w');display=subprocess.Popen(['/usr/bin/Xorg',':97','-noreset','-nolisten','tcp','-ac','-config',str(s.parent/'confectory-v480-integration/xorg.conf'),'-logfile',str(out/'xorg.log')],stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
try:
 for _ in range(150):
  if Path('/tmp/.X11-unix/X97').exists():break
  assert display.poll() is None;time.sleep(.1)
 env['DISPLAY']=':97';env['XDG_CACHE_HOME']=str(s.parent/'confectory-v480-integration/native-cache');started=time.monotonic()
 with (out/'tests.log').open('w') as log:result=subprocess.run([env['CONFECTORY_DOTNET'],str(r/'tests/Confectory.Tests/bin/Release/net10.0/Confectory.Tests.dll'),*methods,'--require-runtime'],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 raw=(out/'tests.log').read_text();rows=re.findall(r'^(PASS|FAIL|SKIP) ([A-Za-z0-9]+Tests\.test_[^\n:]+)',raw,re.M);assert sorted(n for _,n in rows)==sorted(methods)
 record={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'instrumentation':False,'methods':methods,'exit':result.returncode,'elapsedSeconds':time.monotonic()-started,'outcomes':[{'method':n,'outcome':v} for v,n in rows],'logSha256':hashlib.sha256((out/'tests.log').read_bytes()).hexdigest()};(out/'outcomes.json').write_text(json.dumps(record,indent=2)+'\n');print(record,flush=True)
finally:
 os.killpg(display.pid,signal.SIGTERM);display.wait(timeout=10);stream.close()
