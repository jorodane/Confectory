from pathlib import Path
import json,gzip,collections,datetime,hashlib
ROOT=Path(__file__).parent

def analyze(name):
 p=ROOT/name;m=json.loads((p/'metadata.json').read_text());o=json.loads((p/'outcomes.json').read_text());records=[json.loads(x) for x in gzip.open(p/'processes.jsonl.gz','rt')];snaps=[r for r in records if 'processes'in r]
 stat=lambda text:{k:int(v) for k,v in (s.split() for s in text.splitlines())}
 a,b=stat(m['before']['cpu.stat']),stat(m['after']['cpu.stat']);elapsed=m['elapsedSeconds'];events=[]
 for f in (p/'trace').glob('*.jsonl'):
  for r in map(json.loads,f.read_text().splitlines()):r['traceFile']=f.name;events.append(r)
 budgets=[r for r in events if r['phase'].endswith(('-driver:begin','-driver:exit','-driver:timeout'))]
 graph=[]
 for f in (p/'trace').glob('driver-*.jsonl'):
  rr=[json.loads(s) for s in f.read_text().splitlines()];calls=[r for r in rr if r['phase'] in ['command:begin','command:end','blueprint:begin','blueprint:end']]
  if not calls:continue
  ends=[r for r in calls if r['phase'].endswith(':end')];pid=calls[0]['pid'];group=next((row['group'] for rec in records for row in rec.get('births',[]) if row['pid']==pid),'unknown')
  managed=[r for r in budgets if r['phase'].startswith(group+'-driver:')];timeout=next((r for r in managed if r['phase'].endswith(':timeout')),None)
  row={'pid':pid,'group':group,'completedCalls':len(ends),'maxCompletedCallMs':max(r['data']['elapsedMs'] for r in ends),'lastCall':calls[-1]}
  if timeout:
   parse=lambda s:datetime.datetime.fromisoformat(s).timestamp();end_utc=parse(timeout['utc']);cutoff=end_utc-5
   row['completedCallsLast5SecondsBeforeTimeout']=sum(parse(r['utc'])>=cutoff for r in ends)
   row['lastOpenCallAgeAtTimeoutMs']=(end_utc-parse(calls[-1]['utc']))*1000
   # Link wall/monotonic clocks through a Python event that records both clocks.
   anchor=next((r for r in events if isinstance(r['utc'],(float,int))),None)
   if anchor:
    deadline=anchor['monotonicNs']+(end_utc-anchor['utc'])*1e9
    row['childBirthsLast5SecondsBeforeTimeout']=sum(x['group']==group for rec in records if deadline-5e9<=rec['monotonicNs']<=deadline for x in rec.get('births',[]))
    row['childExitsLast5SecondsBeforeTimeout']=sum(x['group']==group for rec in records if deadline-5e9<=rec['monotonicNs']<=deadline for x in rec.get('exits',[]))
  graph.append(row)
 waits=collections.defaultdict(list)
 for r in events:
  if r['phase'].startswith('native-wait:'):waits[(r['pid'],r['data']['wait'])].append(r)
 native=[{'pid':pid,'wait':wait,'samples':len(rr),'first':rr[0],'last':rr[-1],'completed':any(r['phase']=='native-wait:done' for r in rr)} for (pid,wait),rr in sorted(waits.items())]
 for row in native:
  first=datetime.datetime.fromisoformat(row['first']['utc']).timestamp()
  for kind in ['native-button','native-engine']:
   begins=[e for e in budgets if e['phase']==kind+'-driver:begin'];ends=[e for e in budgets if e['phase']==kind+'-driver:exit']
   if begins and ends and datetime.datetime.fromisoformat(begins[0]['utc']).timestamp()<=first<=datetime.datetime.fromisoformat(ends[0]['utc']).timestamp():row['driverKind']=kind
 before_events=stat(m['before']['memory.events']);after_events=stat(m['after']['memory.events'])
 result={'id':name,'headAtLaunch':m['head'],'sourceManifestSha256':m['sourceManifestSha256'],'sourceFileCount':len(m['source']),'workers':m['workers'],'selectedMethods':m['methods'],'methodOutcomes':[row for gate in o.values() for row in gate['outcomes']],'elapsedSeconds':elapsed,
  'resources':{'cpuQuota':m['cpu.max'],'memoryLimitBytes':int(m['memory.max']),'cpuUsedSeconds':(b['usage_usec']-a['usage_usec'])/1e6,'averageCores':(b['usage_usec']-a['usage_usec'])/1e6/elapsed,'cpuThrottledPeriodCount':b['nr_throttled']-a['nr_throttled'],'cpuPeriodCount':b['nr_periods']-a['nr_periods'],'cpuThrottledCounterSeconds':(b['throttled_usec']-a['throttled_usec'])/1e6,'observerCpuSeconds':m['observerCpuSeconds'],'observerAverageCores':m['observerCpuSeconds']/elapsed,'maximumSampledMemoryCurrentBytes':max(int(r['cgroup']['memory.current']) for r in snaps),'maximumSampledOwnedProcesses':max(len(r['processes']) for r in snaps),'maximumSampledLiveGateProcesses':max(sum(p['state']!='Z' for p in r['processes']) for r in snaps),'maximumSampledGateZombies':max(sum(p['state']=='Z' for p in r['processes']) for r in snaps),'observerCpuScope':'Whole Python runner process, including sampling/gzip/source checks/orchestration; not child CPU','maximumCgroupPidsCurrent':max(int(r['cgroup']['pids.current']) for r in snaps),'oomKillDelta':after_events['oom_kill']-before_events['oom_kill']},
  'driverBudgets':budgets,'graphProgress':graph,'nativeWaits':native,'ownershipEvents':[r for r in events if r['phase'] in ['before-confirmed-close','child-count-assert-observation','run-retirement-check','legacy-all-child-count','ui-failure']],
  'uiRejectedResults':[r for r in events if r['phase']=='ui-invoke-result' and not r['data']['ok']],
  'measurementLimits':['Owned process sampling is periodic; short-lived processes may be missed. PID birth identities retained; zombies distinguished from live execution.','Cgroup CPU includes shared services and observer. Throttled counter delta is not a per-operation lost-wall-time estimate.','Peak memory uses sampled memory.current; lifetime memory.peak not attributed to this phase.','Limited workload mix preserves 4 CPU, 17GiB and worker cap, not the complete original 235-method launch/cache history.']}
 (p/'summary.json').write_text(json.dumps(result,indent=2)+'\n');return result
if __name__=='__main__':
 import sys
 for name in sys.argv[1:]:
  r=analyze(name);print(name,r['resources']);print('Graph progress:',r['graphProgress'])
