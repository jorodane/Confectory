Confectory 사이트 실행 방법

1. ZIP 파일의 confectory-site 폴더를 압축 해제합니다.
2. 터미널에서 해당 폴더로 이동합니다.
3. Python이 설치되어 있다면 다음 명령으로 로컬 서버를 시작합니다.
   python3 -m http.server 8000
   Windows에서는 python -m http.server 8000 도 사용할 수 있습니다.
4. 브라우저에서 http://localhost:8000/ 을 엽니다.

HTML/CSS/JavaScript와 이미지 자산을 포함한 정적 사이트입니다. 별도 빌드는 필요하지 않습니다.
브라우저에서 변경한 시연 데이터는 해당 브라우저의 로컬 저장소에 보관되며 이 ZIP에 포함되지 않습니다.
Google Fonts 글꼴은 인터넷 연결이 있을 때 로드되고, 오프라인에서는 시스템 글꼴로 표시됩니다.
