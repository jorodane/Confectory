Confectory — 로컬 실행 및 소스 패키지 v536

이 ZIP의 앱 코드는 배포된 v536과 같습니다.
사이트: https://confectory-workshop.jorodane.chatgpt.site/
소스 커밋: f9d5eb3458ca1b471bd239a2cc89e69038ac4eb8
비교 기준 v508: 0c2f828fec72923e628c6006d73e8823712e9d98

먼저 읽기
- CHANGES-v508-v536.html: 브라우저로 열어 읽는 변경 비교표와 상세 설명
- CHANGES-v508-v536.txt: 같은 변경 내역의 텍스트 파일
- comparison/: 원본 소스 차이와 변경 커밋 이력

PC에서 실행
1. ZIP 전체를 폴더에 압축 해제합니다.
2. Python 3.8 이상을 설치합니다.
3. Windows: start.bat 실행. macOS/Linux: python3 run.py 실행.
   macOS에서는 start.command도 사용할 수 있습니다.
4. http://127.0.0.1:8765/가 열립니다. 터미널을 유지하고 Ctrl+C로 종료합니다.
포트가 사용 중이면 --port 8766, 브라우저 자동 열기를 끄려면 --no-browser를 붙입니다.
예: python3 run.py --port 8766 --no-browser
별도 npm 설치나 빌드는 필요하지 않습니다. 다른 정적 서버에서는 dist를 문서 루트로 지정합니다.

휴대폰
온라인 사이트는 휴대폰 브라우저에서 바로 열 수 있습니다.
로컬 파일을 같은 Wi-Fi의 휴대폰으로 열려면 PC에서 start-lan.bat 또는
python3 run.py --host 0.0.0.0 을 실행하고 휴대폰에서 http://PC의IPv4주소:8765/로 접속합니다.
LAN 실행은 같은 네트워크 기기에도 서버를 엽니다. PC 방화벽의 Python 허용이 필요할 수 있습니다.
세로 모바일에서는 카드 흐름과 전체 화면 노드 편집을 사용하고 그래프 화면으로 전환할 수 있습니다.

실행창
각 실행창은 재생·일시정지·중단·fps와 미리보기 상태를 독립적으로 관리합니다.
한 창의 조작이 다른 창에 영향을 주지 않습니다. 누적 프레임 수는 표시·저장하지 않습니다.

소스 수정
dist/app.js, dist/blueprint.js, dist/style.css를 수정한 뒤
python3 scripts/version-assets.py 를 실행하여 index.html의 해시 파일 참조를 갱신합니다.
.openai/hosting.json은 원래 사이트 배포 설정입니다. 로컬 실행에는 필요하지 않습니다.
manifest.json에는 파일별 SHA-256과 정확한 버전·커밋이 기록되어 있습니다.

데이터와 범위
개인 프로젝트·창 배치·대화 등 온라인 브라우저 저장 데이터는 포함되지 않습니다.
프로젝트는 해당 브라우저의 해당 주소·포트 로컬 저장소에 저장됩니다.
처음 접속한 주소에서는 기본 Demo Project를 생성합니다. 온라인·로컬·기기 간 자동 동기화는 없습니다.
온라인 글꼴을 불러오지 못하면 시스템 글꼴을 사용합니다.
이 패키지는 웹 UI 프로토타입이며, 실제 AI API·C# 컴파일러·외부 실행 엔진은 연결되어 있지 않습니다.
과거 다운로드 ZIP과 불필요한 구버전 캐시 파일은 이 패키지에 넣지 않았습니다.
