Confectory — 로컬 실행본 v480

배포된 v480의 HTML·JavaScript·CSS·이미지를 담은 실행 및 소스 패키지입니다.
사이트: https://confectory-workshop.jorodane.chatgpt.site/
소스 커밋: 8a5e305b628b37918d0d2a13c469f22155c302f9

실행 방법
1. ZIP 전체를 폴더에 압축 해제합니다.
2. Python 3.8 이상을 설치합니다.
3. Windows: start.bat을 실행합니다.
   macOS/Linux: 해당 폴더에서 python3 run.py를 실행합니다.
   macOS에서는 start.command도 사용할 수 있습니다.
4. 브라우저에서 http://127.0.0.1:8765/가 열립니다.
   실행 중에는 터미널을 열어 두세요. Ctrl+C로 종료합니다.

포트가 사용 중이면 python3 run.py --port 8766으로 실행하세요.
브라우저를 자동으로 열지 않으려면 --no-browser를 붙이세요.
별도 npm 설치나 빌드가 필요하지 않습니다.
다른 정적 웹 서버를 사용한다면 dist 폴더를 문서 루트로 지정하세요.
온라인 글꼴을 불러올 수 없으면 시스템 기본 글꼴로 표시됩니다.

포함 파일
- dist/: v480 웹 화면, 소스, 아이콘, 캐릭터 이미지, html2canvas
- run.py, start.bat, start.command: 로컬 실행 도구
- scripts/version-assets.py: 수정한 JS·CSS의 참조 파일명 갱신 도구
- manifest.json: 배포 버전, 소스 커밋, 파일별 SHA-256

소스 수정 시 python3 scripts/version-assets.py를 실행한 뒤 새로고침하세요.
과거 버전 캐시 파일과 이전 버전 ZIP은 제외했으며, 실행에 필요한 파일은 포함했습니다.

저장 데이터
처음 실행하면 기본 데모 데이터가 표시됩니다.
온라인 사이트의 브라우저에 저장된 프로젝트·창 배치·대화 데이터는 이 ZIP에 포함되지 않습니다.
로컬에서 편집한 내용은 해당 브라우저의 로컬 저장소에 보관됩니다.
동일한 브라우저와 주소·포트로 접속하면 저장한 내용을 이어 사용할 수 있습니다.

프로토타입 범위
배포된 v480과 동일한 UI 프로토타입입니다.
실제 AI API, C# 컴파일러, 외부 실행 엔진은 연결되어 있지 않습니다.
