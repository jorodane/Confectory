"""Publish content-addressed asset filenames so caches cannot reuse older JS/CSS."""
import hashlib
from pathlib import Path
import re

root = Path(__file__).resolve().parents[1] / 'dist'
index = root / 'index.html'
html = index.read_text()
for name in ('app.js', 'style.css', 'blueprint.js'):
    source = root / name
    content = source.read_bytes()
    version = hashlib.sha256(content).hexdigest()[:16]
    published_name = f'{source.stem}.{version}{source.suffix}'
    html, count = re.subn(
        r'(["\'])' + re.escape(source.stem) + r'(?:\.[a-f0-9]{16})?' + re.escape(source.suffix) + r'(?:\?v=[a-f0-9]+)?\1',
        lambda match: f'{match[1]}{published_name}{match[1]}',
        html,
    )
    if count != 1:
        raise SystemExit(f'Expected one reference to {name}, found {count}')
    (root / published_name).write_bytes(content)
index.write_text(html)
