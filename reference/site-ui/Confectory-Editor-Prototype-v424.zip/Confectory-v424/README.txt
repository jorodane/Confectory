Confectory — 로컬 실행본 v424

2026-10-15 배포된 사이트 실행본입니다.
사이트: https://confectory-workshop.jorodane.chatgpt.site/
소스 커밋: 21da0b48256439a530c3e2097b2cb354c43e3956

실행
1. ZIP을 폴더에 모두 압축 해제합니다.
2. Python 3.8 이상이 설치되어 있어야 합니다.
3. Windows: start.bat을 실행합니다.
   macOS/Linux: 폴더에서 `python3 run.py`를 실행합니다.
   macOS에서는 start.command도 사용할 수 있습니다.
4. 브라우저에서 http://127.0.0.1:8765/가 열립니다.
   실행 중에는 터미널을 열어 두세요. Ctrl+C로 종료합니다.

포트가 사용 중이면 `python3 run.py --port 8766`으로 실행하세요.
별도 npm 설치나 빌드 없이 실행됩니다.
온라인 글꼴을 불러올 수 없으면 시스템 기본 글꼴로 표시됩니다.
정적 사이트 서버를 사용한다면 dist 폴더를 문서 루트로 지정하세요.

데이터
처음 실행하면 기본 데모 데이터가 표시됩니다.
온라인 사이트의 브라우저에 저장된 프로젝트·창 배치·대화 데이터는 이 ZIP에 포함되지 않습니다.
로컬에서 편집한 데이터는 해당 브라우저의 로컬 저장소에 보관됩니다.
같은 브라우저와 같은 주소·포트를 사용해야 저장된 데이터가 이어집니다.
시크릿 모드나 브라우저 데이터 삭제 시 저장 데이터가 사라질 수 있습니다.

포함 파일
- dist/: 현재 HTML, JavaScript, CSS, 아이콘, 캐릭터 이미지, html2canvas
- run.py, start.bat, start.command: 로컬 실행 도구
- scripts/version-assets.py: 소스를 수정했을 때 참조 파일명을 갱신하는 도구
- manifest.json: 배포 버전과 파일별 SHA-256

소스를 수정한 경우: `python3 scripts/version-assets.py` 실행 후 새로고침하세요.
AI 응답·코드 실행·공유 상태 등은 사이트와 동일한 프로토타입 동작입니다.
