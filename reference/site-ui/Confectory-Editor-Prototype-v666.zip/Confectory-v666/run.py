#!/usr/bin/env python3
"""Run the exported Confectory site using Python's standard library."""
import argparse
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import threading
import webbrowser


class Handler(SimpleHTTPRequestHandler):
    extensions_map = {**SimpleHTTPRequestHandler.extensions_map,
                      '.js': 'application/javascript', '.mjs': 'application/javascript',
                      '.wasm': 'application/wasm', '.glb': 'model/gltf-binary',
                      '.gltf': 'model/gltf+json'}


def main():
    parser = argparse.ArgumentParser(description='Run Confectory locally.')
    parser.add_argument('--host', default='127.0.0.1', help='Use 0.0.0.0 for phones on the same Wi-Fi.')
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--no-browser', action='store_true')
    args = parser.parse_args()
    site = Path(__file__).resolve().parent / 'dist'
    handler = partial(Handler, directory=str(site))
    try:
        server = ThreadingHTTPServer((args.host, args.port), handler)
    except OSError as error:
        raise SystemExit('Cannot start server: {}\nTry: python run.py --port 8766'.format(error))
    browser_host = '127.0.0.1' if args.host == '0.0.0.0' else args.host
    url = 'http://{}:{}/'.format(browser_host, server.server_address[1])
    print('Confectory v666: ' + url, flush=True)
    print('Keep this terminal open. Press Ctrl+C to stop.', flush=True)
    if args.host == '0.0.0.0':
        print('Phone (same Wi-Fi): http://<PC Wi-Fi IPv4 address>:{}/'.format(server.server_address[1]), flush=True)
    if not args.no_browser:
        timer = threading.Timer(0.3, lambda: webbrowser.open(url))
        timer.daemon = True
        timer.start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == '__main__':
    main()
