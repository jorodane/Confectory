/* Visibility audiences, multi-membership privacy and staged policy changes. */
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
global.window=global;global.crypto??=require('node:crypto').webcrypto;
vm.runInThisContext(fs.readFileSync(path.join(__dirname,'../dist/members.js'),'utf8'));
const {Access,ChangeSet,initialize,UNASSIGNED}=ConfectoryMembership;
function fixture(){
 const raw={id:'visibility',objects:[{id:'world',name:'World',group:'concept'}],resources:[],saved:{},confirmed:{}},m=initialize(raw);
 m.groups.push(...[{id:'a',leaderId:'leader'},{id:'a-child',parentId:'a'},{id:'b'},{id:'secret',leaderId:'secret-leader'},{id:'secret-child',parentId:'secret'}].map(group=>({...group,name:group.id,grants:{read:true,write:true},roleIds:[]})));
 for(const [id,groupIds] of [['leader',['a']],['a-person',['a']],['a-child-person',['a-child']],['b-person',['b']],['secret-leader',['secret']],['secret-person',['secret']],['child-person',['secret-child']],['dual',['a','secret']],['unassigned',[]]])m.members.push({id,name:id,status:'active',groupId:groupIds[0]||null,groupIds,helpers:[],helperIds:[]});
 m.members.find(member=>member.id==='secret-person').helpers.push({id:'secret-helper',memberOwnerId:'secret-person'});
 let viewer='self';const a=new Access(raw,{viewer:()=>viewer});return {raw,m,a,as(id){viewer=id;a.capture()},member:id=>m.members.find(member=>member.id===id)};
}
{
 const f=fixture();f.as('b-person');assert(f.a.canSeeGroup('secret'),'old groups remain public');
 f.as('self');const rights=JSON.stringify(f.m.members.map(member=>f.a.effective(member)));assert(f.a.setGroupVisibility('secret',[]));
 f.as('b-person');assert(!f.a.canSeeGroup('secret'));assert(!f.a.canSeeGroup('secret-child'),'a public child cannot bypass a hidden parent');assert(!f.a.canSeeMember(f.member('secret-person')));assert(!f.a.canSeeMember(f.member('child-person')));assert(f.a.canSeeMember(f.member('dual')),'one visible membership keeps a person visible');assert(f.a.canSeeMember(f.member('self')));assert(f.a.canSeeMember(f.member('unassigned')));
 const helper=f.member('secret-person').helpers[0];assert.equal(f.a.helperCan(helper,'observe'),false);assert.equal(f.a.helperEditable(helper),false);assert.equal(f.a.setGroupVisibility('secret',['b']),false,'an outside reader cannot change visibility');assert.equal(f.a.setGroupVisibility('b',[]),false,'membership alone cannot change visibility');
 f.as('secret-person');assert(f.a.canSeeGroup('secret'));assert(f.a.canSeeMember(f.member('secret-leader')));f.as('child-person');assert(f.a.canSeeGroup('secret'));assert(f.a.canSeeGroup('secret-child'));
 f.as('self');assert(f.a.canSeeGroup('secret'));assert.equal(JSON.stringify(f.m.members.map(member=>f.a.effective(member))),rights,'visibility does not alter content access');
}
{
 const f=fixture();assert(f.a.setGroupVisibility('secret',['a','b','a']));assert.deepEqual(f.a.groupVisibility('secret'),['a','b']);
 f.as('a-child-person');assert(f.a.canSeeGroup('secret'),'audience groups include their descendants');f.as('b-person');assert(f.a.canSeeMember(f.member('secret-person')));
 f.as('self');assert(f.a.setGroupVisibility('secret',['b']));f.as('a-person');assert(!f.a.canSeeGroup('secret'));f.as('b-person');assert(f.a.canSeeGroup('secret'));
 f.as('self');assert(f.a.setGroupVisibility('secret',[UNASSIGNED]));f.as('unassigned');assert(f.a.canSeeGroup('secret'));f.as('a-person');assert(!f.a.canSeeGroup('secret'));
 f.as('self');assert(f.a.setGroupVisibility('secret',null));f.as('a-person');assert(f.a.canSeeGroup('secret'));assert.equal(f.a.groupVisibility('secret'),null);
}
{
 const f=fixture();assert(f.a.setGroupVisibility('secret',[]));assert(f.a.setGroupVisibility('secret-child',[]));f.as('secret-leader');assert(f.a.canSeeGroup('secret-child'),'parent leadership retains management visibility');assert(f.a.setGroupVisibility('secret-child',['a']));assert.equal(f.a.setGroupVisibility('a',[]),false,'leadership remains scoped');
 f.as('self');f.m.groups.find(group=>group.id==='b').grants.manageGroups=true;f.as('b-person');assert(f.a.canSeeGroup('secret'),'project group administrators retain access');
}
{
 const f=fixture(),before=JSON.stringify(f.m),tx=new ChangeSet(f.a);assert(tx.access.setGroupVisibility('secret',['b']));tx.checkpoint();assert.equal(JSON.stringify(f.m),before);assert(tx.undo());assert.equal(tx.access.groupVisibility('secret'),null);assert(tx.redo());assert.deepEqual(tx.access.groupVisibility('secret'),['b']);assert(tx.apply());assert.deepEqual(f.a.groupVisibility('secret'),['b']);
 assert(f.a.removeGroup('b'));assert.deepEqual(f.a.groupVisibility('secret'),[],'deleting an audience group must not make a private group public');f.as('a-person');assert(!f.a.canSeeGroup('secret'));
}
{
 const f=fixture();assert.equal(f.a.setGroupVisibility('secret',['missing']),false);assert.equal(f.a.setGroupVisibility('secret','a'),false);assert.equal(f.a.setGroupVisibility('missing',[]),false);
 const secret=f.m.groups.find(group=>group.id==='secret');secret.visibleToGroupIds='invalid';new Access(f.raw);assert.deepEqual(secret.visibleToGroupIds,[],'malformed visibility fails closed');
}
{
 const f=fixture(),rights=JSON.stringify(f.m.members.map(member=>f.a.effective(member)));assert.equal(f.a.groupMemberVisibility('secret'),true,'existing membership disclosure stays enabled');assert(f.a.setGroupMemberVisibility('secret',false));
 f.as('secret-person');assert(!f.a.canSeeGroup('secret'),'a member may be classified without seeing that group');assert(f.a.canSeeMember(f.member('secret-person')),'hiding membership does not hide the viewer identity');assert(!f.a.canSeeMember(f.member('secret-leader')));assert(f.a.access('world','read'));assert(f.a.access('world','write'),'classification still supplies its original permissions');assert.equal(f.a.setGroupMemberVisibility('secret',true),false);
 f.as('dual');assert(!f.a.canSeeGroup('secret'),'another membership cannot bypass an explicit restriction on the subject');assert(f.a.canSeeGroup('a'));f.as('child-person');assert(!f.a.canSeeGroup('secret-child'),'descendants cannot expose the hidden classification through an ancestor path');
 f.as('b-person');assert(f.a.canSeeGroup('secret'),'external audience settings are independent');assert(f.a.canSeeMember(f.member('secret-person')));f.as('secret-leader');assert(f.a.canSeeGroup('secret'),'group management retains visibility');
 f.as('self');assert.equal(JSON.stringify(f.m.members.map(member=>f.a.effective(member))),rights);assert(f.a.setGroupVisibility('secret',['a']));f.as('dual');assert(!f.a.canSeeGroup('secret'),'explicitly selecting the other membership does not reveal the hidden classification');
 f.as('self');assert(f.a.setGroupVisibility('secret',[]));assert.equal(f.a.groupMemberVisibility('secret'),false);f.as('b-person');assert(!f.a.canSeeGroup('secret'));f.as('self');assert(f.a.canSeeGroup('secret'));assert(f.a.setGroupMemberVisibility('secret',true));f.as('secret-person');assert(f.a.canSeeGroup('secret'));
}
{
 const f=fixture(),before=JSON.stringify(f.m),tx=new ChangeSet(f.a);assert(tx.access.setGroupMemberVisibility('secret',false));tx.checkpoint();assert.equal(JSON.stringify(f.m),before);assert(tx.undo());assert(tx.access.groupMemberVisibility('secret'));assert(tx.redo());assert.equal(tx.access.groupMemberVisibility('secret'),false);assert(tx.apply());assert.equal(new Access(f.raw).groupMemberVisibility('secret'),false);
 assert.equal(f.a.setGroupMemberVisibility('missing',false),false);assert.equal(f.a.setGroupMemberVisibility('secret','false'),false);assert(f.a.setGroupMemberVisibility('secret',true));assert.equal(Object.hasOwn(f.m.groups.find(group=>group.id==='secret'),'visibleToMembers'),false,'the default can be restored');
}
console.log('PASS audience and member disclosure, hidden classifications, multi-membership privacy, inherited limits, hidden Helpers, management authority, unchanged ACLs, staged history and deleted audiences');
