/* Ownership previews retain live authority until the entire edited policy is applied. */
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
global.window=global;global.crypto??=require('node:crypto').webcrypto;
vm.runInThisContext(fs.readFileSync(path.join(__dirname,'../dist/members.js'),'utf8'));
const {Access,ChangeSet,initialize,copy}=ConfectoryMembership;
const member=(id,groupId=null)=>({kind:'member',id,groupId}),group=id=>({kind:'group',id});
function fixture(){
 const raw={id:'ownership-preview',objects:[{id:'world',name:'World',group:'concept'},{id:'feature',name:'Feature',group:'feature'}],resources:[{id:'file',name:'File',size:1}],saved:{world:{name:'Original'}},confirmed:{world:{name:'Confirmed'}}},m=initialize(raw);
 m.groups.push({id:'a',name:'A',grants:{read:true,write:true}},{id:'b',name:'B',grants:{read:true,write:true}});
 for(const [id,groupId] of [['person','a'],['other','b'],['loose',null]])m.members.push({id,name:id,title:id,status:'active',groupId,helperIds:[],helpers:[]});
 let viewer='self';const a=new Access(raw,{viewer:()=>viewer});m.organization.root=['member:self','member:loose'];m.organization.order={owner:['group:a','group:b'],'group:a':['member:person'],'group:b':['member:other']};a.capture();
 return {raw,m,a,as(id){viewer=id;a.capture()}};
}
{
 const f=fixture(),before=JSON.stringify(f.m),content=JSON.stringify([f.raw.objects,f.raw.resources,f.raw.saved,f.raw.confirmed]),tx=new ChangeSet(f.a),a=tx.access;
 assert(tx.stageOwnership('person'));assert.equal(a.model.ownerId,'person');assert.equal(tx.pendingOwnerId,'person');assert.equal(JSON.stringify(f.m),before);assert(f.a.isOwner);assert(a.isOwner,'authorization still comes from the live owner');
 assert.deepEqual(a.model.groups,f.m.groups,'staging never creates a group');assert.deepEqual(a.memberGroupIds(a.member),[]);assert.equal(a.organizationContainer(member('self')),'unassigned');assert(a.organizationChildren('unassigned').some(node=>node.id==='self'));assert(a.canManageMember(a.member));assert(a.placeOrganizations([member('self')],group('b'),'inside'));
 assert.deepEqual(a.memberGroupIds(a.member),['b']);assert(a.setMemberPermission('self','project','write',false));assert(a.setMemberPermission('self','domain:feature','read',false));assert(a.setMemberPermission('self','project','read',false));
 assert.equal(a.effective().read,false);assert.equal(a.effective().write,false);assert(a.can('grantPermissions'));assert(a.renameGroup('a','Still editable'));assert(f.a.can('read'));assert(f.a.can('write'));assert.equal(JSON.stringify(f.m),before);
 const groupCount=a.model.groups.length;assert(tx.apply());assert.equal(f.m.ownerId,'person');assert.deepEqual(f.a.memberGroupIds(f.a.member),['b']);assert.equal(f.m.groups.length,groupCount,'apply must not recreate an editor group or rewrite the chosen membership');assert.equal(f.a.can('read'),false);assert.equal(f.a.can('write'),false);assert.equal(f.m.members.find(m=>m.id==='self').personalGrants.read,false);assert(f.a.accessAs(f.m.members.find(m=>m.id==='person'),'world','write'));assert.equal(JSON.stringify([f.raw.objects,f.raw.resources,f.raw.saved,f.raw.confirmed]),content);
}
{
 const f=fixture(),tx=new ChangeSet(f.a),before=JSON.stringify(tx.access.model);assert(tx.stageOwnership('person'));assert(tx.cancelOwnership());assert.equal(JSON.stringify(tx.access.model),before);assert.equal(tx.pendingOwnerId,null);assert.equal(tx.ownershipPreview,null);assert(!tx.dirty);
 assert(tx.access.renameGroup('a','Before preview'));const edited=JSON.stringify(tx.access.model);assert(tx.stageOwnership('loose'));assert(tx.cancelOwnership());assert.equal(JSON.stringify(tx.access.model),edited,'cancel restores direct/root member ordering and keeps preceding changes');
}
{
 const f=fixture(),tx=new ChangeSet(f.a),a=tx.access;assert(tx.stageOwnership('person'));assert(a.placeOrganizations([member('self')],group('b'),'inside'));assert(a.setMemberPermission('self','project','write',false));assert(a.renameGroup('a','Keep this edit'));
 assert(tx.cancelOwnership());assert.equal(a.model.ownerId,'self');assert.deepEqual(a.memberGroupIds(a.member),['b']);assert.equal(a.member.personalGrants.write,false);assert.equal(a.model.groups.find(g=>g.id==='a').name,'Keep this edit');assert.equal(a.model.groups.length,f.m.groups.length);assert.deepEqual(a.model.organization.order['group:a'],['member:person']);assert(tx.dirty);assert(tx.apply());assert(f.a.isOwner);assert(f.a.can('write'),'cancelling the transfer preserves the live owner authority');
}
{
 const f=fixture(),tx=new ChangeSet(f.a),a=tx.access;assert(tx.stageOwnership('person'));const created=a.createGroup(null,'나 편집 그룹');assert(created);assert(a.placeOrganizations([member('self')],group(created.id),'inside'));assert(a.setGroupGrant(created.id,'write',false));assert(tx.cancelOwnership());assert.equal(a.model.groups.find(g=>g.id===created.id).name,'나 편집 그룹');assert.deepEqual(a.memberGroupIds(a.member),[created.id],'cancelling retains a group the user created, regardless of its name');assert(tx.dirty);
}
{
 const f=fixture(),tx=new ChangeSet(f.a),a=tx.access;assert(tx.stageOwnership('person'));tx.checkpoint();assert(a.placeOrganizations([member('self')],group('b'),'inside'));assert(a.setMemberPermission('self','project','write',false));tx.checkpoint();const first=JSON.stringify(a.model);
 assert(tx.stageOwnership('loose'));tx.checkpoint();assert.equal(a.model.ownerId,'loose');assert.deepEqual(a.memberGroupIds(a.member),['b']);assert.equal(a.member.personalGrants.write,false);assert.deepEqual(a.model.organization.order['group:a'],['member:person']);const second=JSON.stringify(a.model);
 assert(tx.undo());assert.equal(JSON.stringify(a.model),first);assert.equal(tx.pendingOwnerId,'person');assert(tx.redo());assert.equal(JSON.stringify(a.model),second);assert.equal(tx.pendingOwnerId,'loose');assert(tx.cancelOwnership());assert.equal(a.model.ownerId,'self');assert.deepEqual(a.model.organization.root,['member:self','member:loose']);assert.deepEqual(a.memberGroupIds(a.member),['b']);assert.equal(a.member.personalGrants.write,false);assert.deepEqual(a.model.groups,f.m.groups);
}
{
 const f=fixture(),tx=new ChangeSet(f.a),a=tx.access;assert(tx.stageOwnership('person'));tx.checkpoint();assert(tx.undo());assert.equal(a.model.ownerId,'self');assert.equal(tx.pendingOwnerId,null);assert.equal(tx.ownershipPreview,null);assert(tx.redo());assert.equal(a.model.ownerId,'person');assert(tx.cancelOwnership());assert(!tx.dirty);assert(tx.stageOwnership('other'));tx.reset();assert(!tx.dirty);assert.equal(a.model.ownerId,'self');assert.equal(tx.ownershipPreview,null);
}
{
 const f=fixture(),tx=new ChangeSet(f.a),a=tx.access;assert(tx.stageOwnership('person'));assert(a.placeOrganizations([member('self')],group('b'),'before'));assert.deepEqual(a.memberGroupIds(a.member),[]);assert.equal(a.organizationContainer(member('self')),'owner');assert(a.placeOrganizations([member('self')],member('person'),'after'));assert.equal(a.organizationContainer(member('self')),'project');
 assert(tx.stageOwnership('other'));assert.equal(a.organizationContainer(member('self')),'project');assert.deepEqual(a.memberGroupIds(a.member),[]);assert(a.isOwner);assert(tx.apply());assert.equal(f.m.ownerId,'other');assert.equal(f.a.organizationContainer(member('self')),'project');assert.deepEqual(f.a.memberGroupIds(f.a.member),[]);assert.equal(f.a.can('write'),false,'apply respects an explicitly ungrouped, read-only former owner');
}
{
 const f=fixture(),groups=copy(f.m.groups),tx=new ChangeSet(f.a),a=tx.access;assert(tx.stageOwnership('person'));assert(tx.stageOwnership('loose'));assert.deepEqual(a.model.groups,groups);assert.equal(a.organizationContainer(member('self')),'unassigned');assert.deepEqual(a.memberGroupIds(a.member),[]);assert(f.a.isOwner);assert(f.a.can('write'));assert(a.can('grantPermissions'));assert(tx.apply());assert.equal(f.m.ownerId,'loose');assert.equal(f.a.organizationContainer(member('self')),'unassigned');assert.deepEqual(f.a.memberGroupIds(f.a.member),[]);assert.deepEqual(f.m.groups,groups);assert(f.a.can('read'));assert.equal(f.a.can('write'),false,'an unplaced former owner inherits the unassigned policy after apply');
}
{
 const f=fixture();f.a.assignGroups(f.a.member,['a','b']);for(const g of f.m.groups)g.grants.write=false;f.a.capture();const groups=copy(f.m.groups),tx=new ChangeSet(f.a),a=tx.access;assert(tx.stageOwnership('person'));assert.deepEqual(a.memberGroupIds(a.member),['a','b'],'existing memberships stay intact even when read-only');assert.deepEqual(a.model.groups,groups);assert.equal(a.organizationContainer(member('self','a')),'group:a');assert.equal(a.organizationContainer(member('self','b')),'group:b');assert(tx.apply());assert.deepEqual(f.a.memberGroupIds(f.a.member),['a','b']);assert.deepEqual(f.m.groups,groups);assert.equal(f.a.can('write'),false);
}
{
 const f=fixture(),before=JSON.stringify(f.m),tx=new ChangeSet(f.a);assert(tx.stageOwnership('person'));tx.access.model.members.find(m=>m.id==='person').status='invited';assert.equal(tx.apply(),false);assert.equal(JSON.stringify(f.m),before);
 const missing=new ChangeSet(f.a);assert(missing.stageOwnership('person'));missing.access.model.members=missing.access.model.members.filter(m=>m.id!=='person');assert.equal(missing.apply(),false);assert.equal(JSON.stringify(f.m),before);
 const wrong=new ChangeSet(f.a);assert(wrong.stageOwnership('person'));wrong.access.model.ownerId='other';assert.equal(wrong.apply(),false);assert.equal(JSON.stringify(f.m),before);
 const bypass=new ChangeSet(f.a);bypass.access.model.ownerId='person';assert.equal(bypass.apply(),false);assert.equal(JSON.stringify(f.m),before);
}
{
 const f=fixture();f.as('person');const before=JSON.stringify(f.m),tx=new ChangeSet(f.a);assert.equal(tx.stageOwnership('other'),false);tx.access.model.ownerId='other';tx.pendingOwnerId='other';tx.ownershipPreview={originalOwnerId:'self'};assert.equal(tx.apply(),false);assert.equal(JSON.stringify(f.m),before);
 f.as('self');const switched=new ChangeSet(f.a);f.as('person');assert.equal(switched.stageOwnership('other'),false);
 f.as('self');const conflict=new ChangeSet(f.a);assert(conflict.stageOwnership('person'));assert(f.a.renameGroup('a','Concurrent change'));const concurrent=JSON.stringify(f.m);assert.equal(conflict.apply(),false);assert.equal(JSON.stringify(f.m),concurrent);
}
console.log('PASS ownership preview and editable former owner, live authority, exact final policy, clean cancellation, retained edits, recipient replacement, positions, undo/redo/reset, atomic apply and authority/conflict guards');
