const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');global.window=global;
vm.runInThisContext(fs.readFileSync(path.join(__dirname,'../dist/members.js'),'utf8'));
const {Access,UNASSIGNED,PROJECT_ROOT,initialize,layoutOrganization,organizationRootRows,organizationDropTarget}=ConfectoryMembership;
const item=(kind,id)=>({kind,id}),member=id=>item('member',id),group=id=>item('group',id),keys=nodes=>nodes.map(node=>node.kind+':'+node.id);
function fixture(){const raw={id:'org',objects:[],resources:[],saved:{},confirmed:{}},m=initialize(raw);m.members.push(...[{id:'leader',groupId:'team'},{id:'reader',groupId:'sub'},{id:'other',groupId:null}].map(person=>({...person,name:person.id,status:'active',helperIds:[],helpers:[]})));m.groups.push({id:'team',name:'Team',parentId:null,leaderId:'leader',grants:{read:true,write:true}},{id:'sub',name:'Sub',parentId:'team',grants:{write:false}},{id:'outside',name:'Outside',parentId:null,grants:{}});let viewer='self';return {raw,m,a:new Access(raw,{viewer:()=>viewer}),as(id){viewer=id}}}
{
 const f=fixture(),lane=item('unassigned',UNASSIGNED),memberIds=f.m.members.map(m=>m.id),groupIds=f.m.groups.map(g=>g.id);
 assert(f.a.placeOrganization(member('other'),group('team'),'before'));assert.equal(f.a.organizationContainer(member('other')),'owner');
 assert(f.a.placeOrganization(member('other'),lane,'inside'));assert(f.a.placeOrganization(group('outside'),group('team'),'before'));
 assert(f.a.placeOrganization(member('reader'),member('other'),'before'));assert.equal(f.m.members.find(m=>m.id==='reader').groupId,null);
 assert.deepEqual(keys(f.a.organizationChildren('owner')),['group:outside','group:team']);assert.deepEqual(keys(f.a.organizationChildren('unassigned')),['member:reader','member:other']);
 assert.deepEqual(keys(f.a.organizationChildren('project')),['member:self','unassigned:'+UNASSIGNED]);assert.equal(f.a.placeOrganization(group('outside'),member('other'),'before'),false);
 assert.deepEqual(f.m.members.map(m=>m.id),memberIds);assert.deepEqual(f.m.groups.map(g=>g.id),groupIds);
 const source=JSON.stringify(f.raw),reloaded=new Access(JSON.parse(source));assert.deepEqual(keys(reloaded.organizationChildren('unassigned')),keys(f.a.organizationChildren('unassigned')));assert.equal(JSON.stringify(reloaded.raw),source);
 assert.equal(f.a.canPlaceOrganization(member('other'),member('leader'),'inside'),false);assert.equal(f.a.canPlaceOrganization(member('other'),null,'before'),false);assert.equal(f.a.canPlaceOrganization(member('other'),member('other'),'before'),false);assert.equal(f.a.canPlaceOrganization(lane,member('self'),'inside'),false);
}
{
 const f=fixture(),before=f.a.effective(f.m.members.find(m=>m.id==='leader')),lane=item('unassigned',UNASSIGNED);
 assert(f.a.placeOrganization(group('team'),member('self'),'before'));assert.deepEqual(keys(f.a.organizationChildren('project')),['group:team','member:self','unassigned:'+UNASSIGNED]);
 assert.equal(f.m.groups.find(g=>g.id==='team').parentId,null);assert.deepEqual(f.a.effective(f.m.members.find(m=>m.id==='leader')),before);
 assert(f.a.placeOrganization(member('other'),member('self'),'after'));assert.equal(f.a.organizationContainer(member('other')),'project');assert(f.a.placeOrganization(member('other'),lane,'inside'));
 f.as('other');assert.equal(f.a.isOwner,false);assert.equal(f.a.can('write'),false);assert.equal(f.a.canPlaceOrganization(member('other'),member('self'),'before'),false);
 f.as('self');assert.equal(f.a.canPlaceOrganization(member('self'),lane,'inside'),false);assert.equal(f.a.canPlaceOrganization(group('team'),group('sub'),'inside'),false);assert.equal(f.a.canPlaceOrganization(group('team'),lane,'inside'),false);
 assert(f.a.placeOrganization(group('team'),member('self'),'inside'));assert.equal(f.a.organizationContainer(group('team')),'owner');assert(f.a.moveMember('other','team'));assert.equal(f.a.organizationContainer(member('other')),'group:team');
 assert(f.a.transferOwnership('leader'));assert.deepEqual(keys(f.a.organizationChildren('project')),['member:leader','unassigned:'+UNASSIGNED]);
}
{
 const f=fixture();f.as('leader');assert.equal(f.a.canPlaceOrganization(group('sub'),member('self'),'before'),false);assert.equal(f.a.canPlaceOrganization(group('outside'),member('reader'),'before'),false);assert(f.a.placeOrganization(member('reader'),member('leader'),'before'));assert.equal(f.m.members.find(m=>m.id==='reader').groupId,'team');
 f.as('reader');assert.equal(f.a.canPlaceOrganization(member('leader'),member('reader'),'after'),false);
}
{
 const leaf=(width,height=55)=>({width,height,children:[]}),input=[{width:146,height:55,children:[leaf(89),{width:220,height:75,children:[leaf(260),leaf(99)]},leaf(112),leaf(171),leaf(91)]}],before=JSON.stringify(input),result=layoutOrganization(input),root=result.nodes[0];
 assert.equal(root.anchor,root.children[2].x);assert.equal(JSON.stringify(input),before);
 const check=nodes=>{for(let i=0;i<nodes.length;i++){const n=nodes[i];assert(n.anchor>=0&&n.anchor<=n.width);if(i){const p=nodes[i-1];assert(n.x-n.anchor>=p.x-p.anchor+p.width+30)}if(n.children.length){const middle=Math.floor(n.children.length/2),axis=n.children.length%2?n.children[middle].x:(n.children[middle-1].x+n.children[middle].x)/2;assert.equal(n.anchor,axis);assert.equal(n.childTop,n.rowHeight+56);check(n.children)}}};check(result.nodes);
 const even=layoutOrganization([{width:100,height:55,children:[leaf(80),leaf(240),leaf(120),leaf(90)]}]).nodes[0];assert.equal(even.anchor,(even.children[1].x+even.children[2].x)/2);
}
{
 const root={kind:'project',width:220,height:70,connectionY:28,children:[{width:500,height:55,children:[]},{width:110,height:55,children:[]},{width:300,height:55,children:[]}]},owner={kind:'member',owner:true,width:100,height:75,connectionY:20,children:[]},peer={kind:'member',width:135,height:88,connectionY:20,children:[]},detached={kind:'group',width:100,height:55,children:[]},input=[root,owner,detached,peer],before=JSON.stringify(input),rows=organizationRootRows(input),result=layoutOrganization(rows),heading=result.nodes[0];
 assert.equal(rows.length,2);assert(rows[0].joint);assert.deepEqual(rows[0].peers,[root,owner,peer]);assert.equal(rows[0].children,root.children);assert.equal(rows[0].headerWidth,479);assert.equal(rows[0].headerAxis,110);assert.equal(rows[0].connectionY,28);assert.equal(rows[0].height,96);assert.equal(heading.anchor,heading.children[1].x,'team connectors stay below the project, not the middle of the people');assert(heading.anchor-rows[0].headerAxis>=0);assert(heading.anchor-rows[0].headerAxis+rows[0].headerWidth<=heading.width);assert.equal(result.nodes[1].kind,'group');assert.equal(JSON.stringify(input),before);
 const many=layoutOrganization(organizationRootRows([root,owner,...Array.from({length:8},()=>({...peer}))])).nodes[0];assert.equal(many.anchor,heading.anchor,'more project-level people extend the right side without moving the project away from its teams');assert(many.width>heading.width);assert.equal(many.children[1].x,many.anchor);
 const folded=layoutOrganization(organizationRootRows([{...root,children:[]},owner,peer])).nodes[0];assert.equal(folded.anchor,root.width/2);assert.equal(folded.children.length,0);assert.equal(folded.width,479);assert.equal(organizationRootRows([root])[0].projectNode,root);

}
{
 const node=(id,left,right,acceptsChildren=true)=>({target:group(id),rect:{left,right,top:100,bottom:155},acceptsChildren}),rows=[{left:20,right:500,nodes:[node('a',40,120),node('b',350,450)]}];
 // Every point in a wide gap maps to its one insertion slot, not just card edges.
 for(const x of [121,150,235,300,349]){const hit=organizationDropTarget(rows,x,127);assert.equal(hit.target.id,'b');assert.equal(hit.position,'before')}
 assert.equal(organizationDropTarget(rows,80,127).position,'inside');assert.equal(organizationDropTarget(rows,380,127).position,'inside');assert.equal(organizationDropTarget(rows,10,127).position,'before');assert.equal(organizationDropTarget(rows,520,127).position,'after');assert.equal(organizationDropTarget(rows,235,190),null);
 rows[0].nodes[0].acceptsChildren=false;assert.equal(organizationDropTarget(rows,75,127).position,'before');assert.equal(organizationDropTarget(rows,85,127).position,'after');
}
{
 const f=fixture(),root=item('project',PROJECT_ROOT),before=JSON.stringify(f.m);f.raw.name='Demo Project';assert.equal(f.a.organizationRecord(root).name,'Demo Project');assert.equal(f.a.organizationContainer(root),null);assert.equal(JSON.stringify(f.m),before,'the project group is a fixed view of the project, not a new permissions group');assert.equal(f.a.canPlaceOrganizations([root],member('other'),'after'),false);assert.equal(f.a.canPlaceOrganization(member('other'),root,'before'),false);
 assert(f.a.placeOrganizations([group('sub')],root,'inside'));assert.equal(f.a.organizationContainer(group('sub')),'owner');assert.equal(f.m.groups.find(g=>g.id==='sub').parentId,null);assert(f.a.placeOrganizations([member('other')],root,'after'));assert.deepEqual(keys(f.a.organizationChildren('project')),['member:other','member:self','unassigned:'+UNASSIGNED]);assert.equal(f.m.ownerId,'self');assert.equal(f.a.effective(f.m.members.find(m=>m.id==='other')).write,false);
 f.as('other');assert.equal(f.a.canPlaceOrganizations([group('team')],root,'inside'),false);assert.equal(f.a.canPlaceOrganizations([member('leader','team')],root,'after'),false);
}
console.log('PASS fixed project root, right-side people and project-centered team connections; separate unassigned lane and explicit owner/project member placement, ordered group/member sibling insertion, persistent ordering, unchanged authority, scoped move checks, cycle guards, connection-axis layout for unequal subtrees, compact shared parent rows and full-gap targeting');
