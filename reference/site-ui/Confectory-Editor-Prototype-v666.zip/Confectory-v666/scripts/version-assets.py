"""Publish content-addressed asset filenames so caches cannot reuse older JS/CSS."""
import hashlib
from pathlib import Path
import re

root = Path(__file__).resolve().parents[1] / 'dist'
index = root / 'index.html'
html = index.read_text()
# Hash the shared scene modules before their importer.
for module in ('voxel-character', 'office-world', 'office-actors', 'resource-preview', 'resource-edit'):
    source_module = root / (module + '.js')
    if not source_module.exists():
        continue
    content = source_module.read_bytes()
    version = hashlib.sha256(content).hexdigest()[:16]
    published = f'{module}.{version}.js'
    (root / published).write_bytes(content)
    total = 0
    for importer in ('office.js', 'office-actors.js', 'app.js'):
        target = root / importer
        if not target.exists() or target == source_module:
            continue
        source, count = re.subn(r'\./' + re.escape(module) + r'(?:\.[a-f0-9]{16})?\.js', './' + published, target.read_text())
        if count:
            target.write_text(source)
            total += count
    if not total:
        raise SystemExit(f'No import found for {module}')
for name in ('members.js', 'agents.js', 'app.js', 'style.css', 'blueprint.js', 'office.js'):
    source = root / name
    content = source.read_bytes()
    version = hashlib.sha256(content).hexdigest()[:16]
    published_name = f'{source.stem}.{version}{source.suffix}'
    html, count = re.subn(
        r'(["\'])' + re.escape(source.stem) + r'(?:\.[a-f0-9]{16})?' + re.escape(source.suffix) + r'(?:\?v=[a-f0-9]+)?\1',
        lambda match: f'{match[1]}{published_name}{match[1]}',
        html,
    )
    if count != 1:
        raise SystemExit(f'Expected one reference to {name}, found {count}')
    (root / published_name).write_bytes(content)
index.write_text(html)
