/* Whole-tree permission actions retain ACL ceilings and one draft history step. */
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
global.window=global;global.crypto??=require('node:crypto').webcrypto;
vm.runInThisContext(fs.readFileSync(path.join(__dirname,'../dist/members.js'),'utf8'));
const {Access,ChangeSet,initialize,UNASSIGNED}=ConfectoryMembership;
function fixture(){
 const raw={id:'batch',objects:[{id:'sprint',name:'Sprint',group:'feature',parent:'movement',inherits:'base'},{id:'movement',name:'Movement',group:'feature',kind:'Category'},{id:'base',name:'Base',group:'concept'},{id:'hidden',name:'Hidden',group:'info'}],resources:[{id:'file',name:'File',parent:'folder',size:3},{id:'folder',name:'Folder',kind:'folder'}],saved:{},confirmed:{}},m=initialize(raw);
 m.groups.push(...[{id:'team',leaderId:'leader'},{id:'child',parentId:'team'},{id:'other'}].map(group=>({...group,name:group.id,grants:{read:true,write:true},roleIds:[],memberManagers:[]})));
 for(const [id,groupId] of [['leader','team'],['person','child'],['outsider','other'],['unassigned',null]])m.members.push({id,name:id,status:'active',groupId,groupIds:groupId?[groupId]:[],roleIds:[],grants:{},personalGrants:{},helperIds:[],helpers:[]});
 let viewer='self';const a=new Access(raw,{viewer:()=>viewer});return {raw,m,a,as(id){viewer=id;a.capture()}};
}
{
 const f=fixture(),content=JSON.stringify([f.raw.objects,f.raw.resources]);assert(f.a.setAllPermissions('child','read',false));for(const key of f.a.permissionKeys())assert.equal(f.a.permissionValue('child',key,'read'),false,key);
 assert.equal(f.a.canSetAllPermissions('child','read',false),false);assert.equal(f.a.setAllPermissions('child','write',true),false,'write cannot enable read implicitly');
 assert(f.a.setAllPermissions('child','read',true));for(const key of f.a.permissionKeys())assert(f.a.permissionValue('child',key,'read'),key+' must enable after both parents and domains');assert.equal(f.a.canSetAllPermissions('child','read',true),false);
 const reads=f.a.permissionKeys().map(key=>f.a.permissionValue('child',key,'read'));assert(f.a.setAllPermissions('child','write',false));assert.deepEqual(f.a.permissionKeys().map(key=>f.a.permissionValue('child',key,'read')),reads);for(const key of f.a.permissionKeys())assert.equal(f.a.permissionValue('child',key,'write'),false,key);
 assert(f.a.setAllPermissions('child','write',true));for(const key of f.a.permissionKeys())assert(f.a.permissionValue('child',key,'write'),key);assert.equal(JSON.stringify([f.raw.objects,f.raw.resources]),content,'policy batching never edits project content');
}
{
 const f=fixture();assert(f.a.setPermission('team','object:base','read',false));assert(f.a.setPermission('team','domain:feature','write',false));assert(f.a.setPermission(null,'project','write',true));assert(f.a.setPermission(null,'domain:resource','write',false));f.m.rules['object:sprint']={'group:child':{read:true,write:true}};
 assert(f.a.setAllPermissions('child','read',false));assert(f.a.setAllPermissions('child','read',true));assert.equal(f.a.permissionValue('child','object:base','read'),false);assert.equal(f.a.permissionValue('child','object:sprint','read'),false,'a second, hidden dependency still caps the child');assert(f.a.permissionValue('child','object:movement','read'));
 f.m.groups.find(group=>group.id==='child').grants.write=false;assert(f.a.setAllPermissions('child','write',true));assert.equal(f.a.permissionValue('child','object:movement','write'),false);assert.equal(f.a.permissionValue('child','resource:file','write'),false);assert(f.a.permissionValue('child','object:hidden','write'));
}
{
 const f=fixture(),subject={memberId:'person'};assert(f.a.setAllPermissions(subject,'read',false));assert.equal(f.a.effective(f.m.members.find(member=>member.id==='person')).read,false);assert(f.a.setAllPermissions(subject,'read',true));assert(f.a.setAllPermissions(subject,'write',false));assert(f.a.setAllPermissions(subject,'write',true));
 assert(f.a.setPermission('team','object:base','read',false));assert(f.a.setAllPermissions(subject,'read',false));assert(f.a.setAllPermissions(subject,'read',true));assert.equal(f.a.memberPermissionValue('person','object:sprint','read'),false,'personal settings cannot bypass inherited restrictions');assert(f.a.memberPermissionValue('person','resource:file','read'));
 assert(f.a.setAllPermissions(UNASSIGNED,'write',true));assert(f.a.permissionValue(UNASSIGNED,'resource:file','write'));assert(f.a.setAllPermissions(UNASSIGNED,'write',false));assert.equal(f.a.permissionValue(UNASSIGNED,'resource:file','write'),false);
}
{
 const f=fixture();assert(f.a.setPermission('team','object:hidden','read',false));f.as('leader');assert(!f.a.permissionKeys().includes('object:hidden'),'actor-hidden content is not a bulk target');const other=JSON.stringify(f.m.groups.find(group=>group.id==='other'));
 assert(f.a.setAllPermissions('child','read',false));assert(f.a.setAllPermissions('child','read',true));assert.equal(f.a.permissionValue('child','object:hidden','read'),false);assert.equal(f.a.setAllPermissions('other','read',false),false);assert.equal(JSON.stringify(f.m.groups.find(group=>group.id==='other')),other);
 f.as('outsider');const before=JSON.stringify(f.m);assert.equal(f.a.setAllPermissions('child','read',false),false);assert.equal(f.a.setAllPermissions({memberId:'person'},'write',false),false);assert.equal(JSON.stringify(f.m),before,'a rejected action has no partial effects');
}
{
 const f=fixture(),before=JSON.stringify(f.m),tx=new ChangeSet(f.a);assert(tx.access.setAllPermissions('child','read',false));assert(tx.checkpoint());assert.equal(tx.past.length,1);assert.equal(JSON.stringify(f.m),before);assert(tx.undo());assert.equal(JSON.stringify(tx.access.model),before,'one undo restores the whole hierarchy');assert(tx.redo());assert.equal(tx.access.permissionValue('child','resource:file','read'),false);assert(tx.apply());assert.equal(f.a.permissionValue('child','object:sprint','read'),false);assert.equal(tx.canUndo,false);
}
{
 const f=fixture(),before=JSON.stringify(f.m);for(const args of [['missing','read',false],['child','inviteMembers',true],['child','read','false'],[{memberId:'missing'},'read',false],[{memberId:'self'},'read',false]])assert.equal(f.a.setAllPermissions(...args),false);assert.equal(JSON.stringify(f.m),before);
}
console.log('PASS whole-tree read/write batches, dual dependencies, group/global/personal ceilings, unassigned permissions, scoped authority, hidden targets, unchanged content and atomic draft history');
