/* Run with node scripts/test-membership.cjs. No browser or package install required. */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
global.window = global;
vm.runInThisContext(fs.readFileSync(path.join(__dirname, '../dist/members.js'), 'utf8'));
const {Access, initialize, copy} = ConfectoryMembership;
function fixture() {
  const raw = {id:'policy-test',objects:[
    {id:'world',name:'World',kind:'Category'},
    {id:'slime',name:'Slime',parent:'world',helper:'helper'},
    {id:'child',name:'Child',parent:'slime'},
    {id:'public',name:'Public',parent:'world'}
  ],resources:[{id:'folder',name:'PrivateFiles',kind:'folder'},
    {id:'file',parent:'folder',name:'secret.txt',size:3}],saved:{},confirmed:{}};
  const model=initialize(raw,{name:'Owner'},['helper']);
  model.members.push(
    {id:'leader',name:'Leader',status:'active',groupId:'team',roleIds:[],grants:{},helperIds:[],helpers:[]},
    {id:'reader',name:'Reader',status:'active',groupId:'sub',roleIds:[],grants:{},helperIds:[],helpers:[]},
    {id:'pending',name:'Invited',status:'invited',roleIds:[],grants:{},helperIds:[],helpers:[]}
  );
  model.groups.push({id:'team',name:'Team',grants:{read:true,write:true},leaderId:'leader'},
    {id:'sub',name:'Sub',parentId:'team',grants:{read:true,write:false},leaderId:null});
  let viewer='self';const access=new Access(raw,{viewer:()=>viewer});
  return {raw,model,access,view:access.project,as(id){viewer=id;access.capture()}};
}
{
  const f=fixture();assert(f.access.can('manageGroups'));assert.equal(initialize(f.raw),f.model);
  f.as('pending');assert.equal(f.access.can('read'),false);assert.equal(f.view.objects.length,0);
  f.as('reader');assert(f.access.access('public','read'));assert.equal(f.access.access('public','write'),false);
  f.model.rules['object:public']={'group:sub':{write:true}};
  assert.equal(f.access.access('public','write'),false); // An element cannot bypass its group's write ceiling.
  f.as('self');assert(f.access.setGroupGrant('sub','write',true));f.as('reader');
  assert(f.access.access('public','write'));
  f.model.rules['object:public']['group:sub'].read=false;
  assert.equal(f.access.access('public','write'),false);
}
{
  const f=fixture();f.model.rules['object:slime']={'group:team':{read:false}};
  f.model.rules['object:child']={'group:sub':{read:true}};
  f.model.rules['resource:folder']={'group:sub':{read:false}};
  f.as('reader');assert.equal(f.access.access('child'),false);
  assert.deepEqual([...f.view.objects].map(item=>item.id),['world','public']);
  assert.equal(f.view.resources.length,0);assert.equal(f.raw.resources.length,2);
  assert.deepEqual(copy(f.view.objects).map(item=>item.id),['world','public']);
}
{
  const f=fixture();f.as('reader');
  f.view.objects.find(item=>item.id==='public').name='Unauthorized';
  f.view.objects=f.view.objects.filter(item=>item.id!=='slime');
  f.view.objects.push({id:'unauthorized',name:'Unauthorized'});f.access.protect();
  assert.equal(f.raw.objects.find(item=>item.id==='public').name,'Public');
  assert(f.raw.objects.some(item=>item.id==='slime'));assert(!f.raw.objects.some(item=>item.id==='unauthorized'));
  f.as('leader');f.model.rules['object:slime']={'group:team':{read:false}};f.access.capture();
  f.view.objects=f.view.objects.filter(item=>item.id!=='public');f.access.protect();
  assert(!f.raw.objects.some(item=>item.id==='public'));assert(f.raw.objects.some(item=>item.id==='slime'));
}
{
  const f=fixture();f.as('leader');assert(f.access.canManageGroup('sub'));assert(f.access.canManageMember(f.model.members.find(m=>m.id==='reader')));
  assert.equal(f.access.can('grantPermissions'),false);assert.equal(f.access.canManageGroup('other'),false);
  assert.equal(f.access.ceiling('sub').write,true);assert.equal(f.access.ceiling('other').write,undefined);
  f.model.groups.find(group=>group.id==='sub').grants.grantPermissions=true;f.as('reader');
  assert(f.access.can('grantPermissions'));assert.equal(f.access.ceiling('sub').write,false);
}
{
  const f=fixture(),helper={id:'helper',workers:[['A','working','Private details','Root / World / Slime']],workerElements:{A:[['Slime','쓰기']]}};
  f.model.rules['object:slime']={'group:sub':{read:false}};f.as('reader');
  assert(f.access.helperCan(helper,'observe'));assert(f.access.helperCan(helper,'inspectTasks'));
  assert.equal(f.access.helperCan(helper,'chat'),false);assert.equal(f.access.helperCan(helper,'editSettings'),false);
  const view=f.access.helperView(helper);assert.equal(view.workers[0][2],'작업 중');assert.equal(view.workers[0][3],'');
  assert.equal(view.workers[0][4].hiddenTarget,true);assert.deepEqual(view.workerElements.A,[]);
  assert.equal(helper.workers[0][2],'Private details');
  f.model.helperAccess.helper={everyone:{observe:true,inspectTasks:true,chat:true}};
  assert(f.access.helperCan(helper,'chat'));assert(f.access.taskHidden(helper,{objectId:'missing'}));
}
{
  const raw={id:'pack',kind:'pack',objects:[]};const access=new Access(raw);
  assert.equal(access.project,raw);assert.equal(raw.membership,undefined);
  assert.equal(access.transferOwnership('self'),false);
}
{
  const f=fixture(),original=copy(f.model),owner=f.model.members.find(m=>m.id==='self');
  assert.equal(f.access.transferOwnership('pending'),false);
  assert.equal(f.access.transferOwnership('missing'),false);
  assert.equal(f.access.transferOwnership('self'),false);
  assert.deepEqual(f.model,original);
  f.as('leader');f.model.groups.find(group=>group.id==='team').grants.grantPermissions=true;
  assert(f.access.can('grantPermissions'));assert.equal(f.access.transferOwnership('reader'),false);
  f.as('self');f.model.rules['object:slime']={everyone:{read:false}};
  const helpers=copy(owner.helperIds),targetBefore=copy(f.model.members.find(m=>m.id==='reader')),groupsBefore=copy(f.model.groups);
  assert(f.access.transferOwnership('reader'));assert.equal(f.model.ownerId,'reader');
  assert.equal(f.access.isOwner,false);assert.equal(f.access.can('manageGroups'),false);
  assert(f.access.can('read'));assert.equal(f.access.can('write'),false);
  assert.equal(f.access.access('slime','read'),false);
  assert.deepEqual(owner.helperIds,helpers);assert.deepEqual(f.model.members.find(m=>m.id==='reader'),targetBefore);
  assert.notEqual(owner.title,'프로젝트장');assert.deepEqual(f.model.groups,groupsBefore);assert.deepEqual(f.access.memberGroupIds(owner),[]);assert.equal(f.access.organizationContainer({kind:'member',id:'self'}),'unassigned');
  // Recompute the write boundary as soon as ownership changes, including for
  // object references held by an editor before losing the owner's ACL bypass.
  f.raw.objects.find(item=>item.id==='slime').name='Forbidden edit after transfer';f.access.protect();
  assert.equal(f.raw.objects.find(item=>item.id==='slime').name,'Slime');
  assert.equal(initialize(f.raw).ownerId,'reader');
  f.as('reader');assert(f.access.isOwner);assert(f.access.can('manageGroups'));
  assert(f.access.access('slime','write'));assert.equal(f.access.canManageMember(f.access.member),false);
  assert(f.access.transferOwnership('self'));assert.equal(f.model.ownerId,'self');
}
console.log('PASS group-only permissions, invitation state, scoped leadership, delegation ceilings, ACL ancestry, write protection, helper sharing, task privacy and owner transfer');
