Confectory — 로컬 실행 및 소스 패키지 v666

이 ZIP의 앱 코드는 게시된 v666과 같습니다.
사이트: https://confectory-workshop.jorodane.chatgpt.site/
소스 커밋: d6d8a63575a3d1addafc9ab0b558aa3fec600a46

PC에서 실행
1. ZIP 전체를 폴더에 압축 해제합니다.
2. Python 3.8 이상을 설치합니다.
3. Windows: start.bat 실행.
   macOS: start.command 실행 또는 터미널에서 python3 run.py 실행.
   Linux: 터미널에서 python3 run.py 실행.
4. http://127.0.0.1:8765/가 열립니다. 터미널을 유지하고 Ctrl+C로 종료합니다.
포트가 사용 중이면 --port 8766, 브라우저 자동 열기를 끄려면 --no-browser를 붙입니다.
예: python3 run.py --port 8766 --no-browser
별도 npm 설치나 빌드는 필요하지 않습니다. 다른 정적 서버에서는 dist를 문서 루트로 지정합니다.
3D 화면과 모듈을 불러오기 위해 index.html 더블클릭 대신 실행 스크립트를 사용합니다.

휴대폰에서 로컬 실행
같은 Wi-Fi의 PC에서 start-lan.bat 또는 python3 run.py --host 0.0.0.0 을 실행하고
휴대폰에서 http://PC의IPv4주소:8765/로 접속합니다.
이 모드에서는 같은 네트워크 기기가 앱에 접속할 수 있습니다.

포함한 파일
- dist/: v666 실행 파일, 편집 가능한 JS·CSS 소스, 이미지와 3D 라이브러리.
- scripts/: 정적 파일 해시 갱신 스크립트와 현재 소스의 검증 스크립트.
- README.md: 기존 프로젝트 문서.
- .openai/hosting.json: 원래 사이트 배포 설정. 로컬 실행에는 필요하지 않습니다.
- manifest.json: 버전·소스 커밋과 패키지 파일들의 SHA-256.

소스 수정
dist의 JS 또는 CSS를 수정한 뒤 python3 scripts/version-assets.py 를 실행합니다.
브라우저를 새로고침하면 갱신된 파일을 불러옵니다.
기존 배포의 구버전 해시 파일과 과거 다운로드 ZIP은 이 패키지에서 제외했습니다.

데이터와 범위
온라인 브라우저에 저장한 개인 프로젝트·창 배치·대화 데이터는 이 ZIP에 포함되지 않습니다.
로컬 주소에 처음 접속하면 기본 Demo Project를 생성하고 해당 브라우저의 저장소에 저장합니다.
온라인 사이트와 로컬 실행, 다른 기기 사이의 저장 데이터는 자동 동기화되지 않습니다.
앱 이미지와 3D 라이브러리는 함께 들어 있습니다. 온라인 글꼴을 불러오지 못하면 시스템 글꼴을 사용합니다.
이 패키지는 웹 UI 프로토타입이며 실제 AI API·컴파일러·외부 실행 엔진은 연결되어 있지 않습니다.
