@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel% equ 0 (
  py -3 run.py --host 0.0.0.0
) else (
  python run.py --host 0.0.0.0
)
pause
