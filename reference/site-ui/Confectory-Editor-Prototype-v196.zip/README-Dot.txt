Confectory · Editor Prototype — Dot 전달용
추출 기준: Sites 배포 버전 196 (2026-10-11)

이 ZIP은 Confectory 에디터의 인터랙티브 UI/UX 프로토타입이다. 실제 Confectory 엔진의 소스나 기능 명세의 완전한 구현은 아니다.

시작 파일: index.html
화면 스타일: style.css
상태와 상호작용: app.js
이미지와 보조 스크립트: assets/
아이콘: ConfectoryIcon.svg

상대 경로를 유지한 채 압축을 풀어 사용한다. 브라우저에서 로컬 파일 접근이 제한되면 이 폴더를 간단한 정적 HTTP 서버로 열면 된다. 예: python -m http.server 8000, 이후 http://localhost:8000/
프로토타입의 일부 화면 상태는 브라우저 localStorage에 저장된다.
